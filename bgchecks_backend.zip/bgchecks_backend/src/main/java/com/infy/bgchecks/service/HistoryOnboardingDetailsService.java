package com.infy.bgchecks.service;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.OnboardingDetails;

public interface HistoryOnboardingDetailsService {

	public void addHistoryOnboardingDetails(String role, OnboardingDetails onboardingDetails);
	
	public void updateHistoryOnboardinDetails(String role,OnboardingDetails onboardingDetails) throws Exception;
	
	public void deleteHistoryOnboardinDetails(String role,OnboardingDetails onboardingDetails);

}
