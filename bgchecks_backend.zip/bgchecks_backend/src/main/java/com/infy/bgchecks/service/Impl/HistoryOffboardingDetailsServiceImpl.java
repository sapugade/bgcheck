package com.infy.bgchecks.service.Impl;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.HistoryOffboardingDetails;
import com.infy.bgchecks.entity.HistoryOnboardingDetails;
import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.entity.OnboardingDetails;
import com.infy.bgchecks.repository.HistoryOffboardingDetailsRepository;
import com.infy.bgchecks.repository.HistoryOnboardingDetailsRepository;
import com.infy.bgchecks.service.HistoryOffboardingDetailsService;
import com.infy.bgchecks.service.HistoryOnboardingDetailsService;

@Service
public class HistoryOffboardingDetailsServiceImpl implements HistoryOffboardingDetailsService {

	@Autowired
	HistoryOffboardingDetailsRepository historyOffboardingDetailsRepo;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public void addHistoryOffboardingDetails(String role, OffboardingDetails offboardingDetails) {
		
		HistoryOffboardingDetails historyOffboardingDetails = dtoToHistoryOffboardingDetails(offboardingDetails);
		historyOffboardingDetails.setCreatedByUser(role);
		historyOffboardingDetails.setUpdatedByUser(role);
		historyOffboardingDetails.setAction("A");
		
		this.historyOffboardingDetailsRepo.save(historyOffboardingDetails);
		
	}


	@Override
	public void updateHistoryOffboardinDetails(String role, OffboardingDetails offboardingDetails) throws Exception {
		HistoryOffboardingDetails historyOffboardingDetails = dtoToHistoryOffboardingDetails(offboardingDetails);
		historyOffboardingDetails.setCreatedByUser(role);
		historyOffboardingDetails.setUpdatedByUser(role);
		historyOffboardingDetails.setAction("U");
		
		this.historyOffboardingDetailsRepo.save(historyOffboardingDetails);
	}

	@Override
	public void deleteHistoryOffboardinDetails(String role, OffboardingDetails offboardingDetails) {
		HistoryOffboardingDetails historyOffboardingDetails = dtoToHistoryOffboardingDetails(offboardingDetails);
		historyOffboardingDetails.setCreatedByUser(role);
		historyOffboardingDetails.setUpdatedByUser(role);
		historyOffboardingDetails.setAction("D");
		
		this.historyOffboardingDetailsRepo.save(historyOffboardingDetails);
	}
	

	private HistoryOffboardingDetails dtoToHistoryOffboardingDetails(OffboardingDetails offboardingDetails) {
		HistoryOffboardingDetails historyOffboardingDetails = this.modelMapper.map(offboardingDetails, HistoryOffboardingDetails.class);
		return historyOffboardingDetails;
	}
	

}
