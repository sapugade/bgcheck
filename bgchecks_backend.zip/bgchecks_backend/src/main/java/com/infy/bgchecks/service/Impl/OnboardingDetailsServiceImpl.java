package com.infy.bgchecks.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.OnboardingDetails;
import com.infy.bgchecks.repository.OnboardingDetailsRepository;
import com.infy.bgchecks.service.OnboardingDetailsService;
;

@Service
public class OnboardingDetailsServiceImpl implements OnboardingDetailsService{
	
	@Autowired
	OnboardingDetailsRepository onboardingDetailsRepository;
	
	@Autowired
	ModelMapper modelMapper;

	@Override
	public OnboardingDetails addOnboardingDetails(String role,OnboardingDetailsDto onboardingDetailsDto) {
		
		OnboardingDetails onboardingDetails = dtoToBgchecks(onboardingDetailsDto);
        onboardingDetails.setCreatedByUser(role);
        onboardingDetails.setUpdatedByUser(role);
        
        Optional<OnboardingDetails> optional = this.onboardingDetailsRepository.findByEmployeeId(onboardingDetailsDto.getEmployeeId());	         	
		
        if(optional.isPresent())
        {
        	return null;
        }else
        {
        	return this.onboardingDetailsRepository.save(onboardingDetails);
        }
	}
	
	@Override
	public Optional<OnboardingDetails> getOnboardingDetailsById(Integer employeeId) {
		Optional<OnboardingDetails> onboardingDetails = onboardingDetailsRepository.findByEmployeeId(employeeId);
		return onboardingDetails;
		
	}

	@Override
	public List<OnboardingDetails> searchOnboardingDetails(OnboardingDetails onboardingDetails) {
		List<OnboardingDetails> onboardingDetailsList = new ArrayList<>();
		if(onboardingDetails.getEmployeeId()!=null) {
			Optional<OnboardingDetails> onboardingDetailsOptional = this.onboardingDetailsRepository.findByEmployeeId(onboardingDetails.getEmployeeId());
			onboardingDetailsList.add(onboardingDetailsOptional.get());
		}
		else if(onboardingDetails.getName()!=null) {
			onboardingDetailsList = this.onboardingDetailsRepository.findByName(onboardingDetails.getName());
		}
		else if(onboardingDetails.getInfyMailId()!=null) {
			onboardingDetailsList = this.onboardingDetailsRepository.findByInfyMailId(onboardingDetails.getInfyMailId());
		}
		else if(onboardingDetails.getProjectUnit()!=null) {
			onboardingDetailsList = this.onboardingDetailsRepository.findByProjectUnit(onboardingDetails.getProjectUnit());
		}
		else if(onboardingDetails.getOverallStatus()!=null) {
			onboardingDetailsList = this.onboardingDetailsRepository.findByOverallStatus(onboardingDetails.getOverallStatus());
		}else {
			onboardingDetailsList = this.onboardingDetailsRepository.findAll();
		}
		return onboardingDetailsList;
	}

	@Override
	public OnboardingDetails updateOnboardingDetails(String role, OnboardingDetailsDto onboardingDetailsDto) throws Exception {

		OnboardingDetails onboardingDetails = this.onboardingDetailsRepository.findByEmployeeId(onboardingDetailsDto.getEmployeeId()).orElseThrow(()->new Exception("employee id not found"+onboardingDetailsDto.getEmployeeId()));
		
		if(!onboardingDetailsDto.getName().trim().isEmpty()) {
			onboardingDetails.setName(onboardingDetailsDto.getName());
		}
		if(onboardingDetailsDto.getInfyMailId()!=null && !(onboardingDetailsDto.getInfyMailId().trim().isEmpty())
				&& onboardingDetailsDto.getInfyMailId()!="") {
			onboardingDetails.setInfyMailId(onboardingDetailsDto.getInfyMailId());
		}
		if(onboardingDetailsDto.getClientMailId()!=null && !(onboardingDetailsDto.getClientMailId().trim().isEmpty())
				&& onboardingDetailsDto.getClientMailId()!="") {
			onboardingDetails.setClientMailId(onboardingDetailsDto.getClientMailId());
		}	
		if(!onboardingDetailsDto.getProjectUnit().isEmpty()) {
			onboardingDetails.setProjectUnit(onboardingDetailsDto.getProjectUnit());
		}
		if(!onboardingDetailsDto.getAhdNumber().isEmpty()) {
			onboardingDetails.setAhdNumber(onboardingDetailsDto.getAhdNumber());
		}
		if(onboardingDetailsDto.getAhdRequestDate()!=null) {
			onboardingDetails.setAhdRequestDate(onboardingDetailsDto.getAhdRequestDate());
		}
		if(onboardingDetailsDto.getInitiationDate()!=null) {
			onboardingDetails.setInitiationDate(onboardingDetailsDto.getInitiationDate());
		}
		if(!onboardingDetailsDto.getInitiationVendor().isEmpty()) {
			onboardingDetails.setInitiationVendor(onboardingDetailsDto.getInitiationVendor());
		}
		if(!onboardingDetailsDto.getCaseRefNoFromVendor().isEmpty()) {
			onboardingDetails.setCaseRefNoFromVendor(onboardingDetailsDto.getCaseRefNoFromVendor());
		}
		if(!onboardingDetailsDto.getBgcLocation().isEmpty()) {
			onboardingDetails.setBgcLocation(onboardingDetailsDto.getBgcLocation());
		}
		if(!onboardingDetailsDto.getLegalDocumentsSigned().isEmpty()) {
			onboardingDetails.setLegalDocumentsSigned(onboardingDetailsDto.getLegalDocumentsSigned());
		}
		if(onboardingDetailsDto.getFullBgcEta()!=null) {
			onboardingDetails.setFullBgcEta(onboardingDetailsDto.getFullBgcEta());
		}
		if(onboardingDetailsDto.getBgcMinimumCompletionDate()!=null) {
			onboardingDetails.setBgcMinimumCompletionDate(onboardingDetailsDto.getBgcMinimumCompletionDate());
		}
		if(onboardingDetailsDto.getOdcAccessDate()!=null) {
			onboardingDetails.setOdcAccessDate(onboardingDetailsDto.getOdcAccessDate());
		}
		if(onboardingDetailsDto.getReGrantOdcAccessDate()!=null) {
			onboardingDetails.setReGrantOdcAccessDate(onboardingDetailsDto.getReGrantOdcAccessDate());
		}
		if(onboardingDetailsDto.getFullBgCompDate()!=null) {
			onboardingDetails.setFullBgCompDate(onboardingDetailsDto.getFullBgCompDate());
		}
		if(onboardingDetailsDto.getAge()!=null) {
			onboardingDetails.setAge(onboardingDetailsDto.getAge());
		}
		if(!onboardingDetailsDto.getOverallStatus().isEmpty()) {
			onboardingDetails.setOverallStatus(onboardingDetailsDto.getOverallStatus());
		}
		if(!onboardingDetailsDto.getLineManager().isEmpty()) {
			onboardingDetails.setLineManager(onboardingDetailsDto.getLineManager());
		}
		if(!onboardingDetailsDto.getComments().isEmpty()) {
			onboardingDetails.setComments(onboardingDetailsDto.getComments());
		}
		
		onboardingDetails.setUpdatedByUser(role);
		this.onboardingDetailsRepository.save(onboardingDetails);
		onboardingDetails.setCreatedByUser(onboardingDetails.getCreatedByUser());
		return onboardingDetails;
	}

	@Override
	public OnboardingDetails deleteOnboardingDetails(Integer employeeId) {
		
		Optional<OnboardingDetails> onboardingDetails = this.onboardingDetailsRepository.findByEmployeeId(employeeId);
		if(onboardingDetails.isPresent()) {
			this.onboardingDetailsRepository.deleteById(onboardingDetails.get().getId());
			return onboardingDetails.get();
		}
		return null;
	}

	public OnboardingDetails dtoToBgchecks(OnboardingDetailsDto onboardingDetailsDto)
	{
		OnboardingDetails onboardingDetails = this.modelMapper.map(onboardingDetailsDto, OnboardingDetails.class);
		return onboardingDetails;
		
	}
	
	public OnboardingDetailsDto BgchecksToDto(Optional<OnboardingDetails> onboardingDetails) 
	{
		OnboardingDetailsDto onboardingDetailsDto = this.modelMapper.map(onboardingDetails, OnboardingDetailsDto.class);
		return onboardingDetailsDto;
	}

	@Override
	public List<String> autocompleteFields(String fields) {
		List<String> data = new ArrayList<>();
		if(fields.equals("id")) {
			data = this.onboardingDetailsRepository.findAll().stream().map((details)-> details.getEmployeeId()+"").collect(Collectors.toList());
		}
		else if(fields.equals("name")) {
			data = this.onboardingDetailsRepository.findAll().stream().map((details)-> details.getName()).collect(Collectors.toList());
			data = data.stream().distinct().collect(Collectors.toList());
		}
		else if(fields.equals("mailid")) {
			data = this.onboardingDetailsRepository.findAll().stream().map((details)-> details.getInfyMailId()).collect(Collectors.toList());
			data.remove(null);
		}
		else if(fields.equals("overall_status")) {
			data = this.onboardingDetailsRepository.findAll().stream().map((details)-> details.getOverallStatus()).collect(Collectors.toList());			
			data = data.stream().distinct().collect(Collectors.toList());
			data.remove(null);
		}
		return data;
	}

	




	

}
