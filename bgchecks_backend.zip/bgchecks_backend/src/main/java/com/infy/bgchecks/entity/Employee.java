package com.infy.bgchecks.entity;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

public class Employee {

	
	private Integer employeeId;

	private String employeeName;
	
	private String employeeRole;
	
	private String projectUnit;
	
	private String projectCode;
	
	private String lineManager;

	private String location;
	
	private String allocatedCity;
	
	private String currentCountry;
	
	private String currentCity;
	
	private LocalDate birthDate;

	private String emailId;
	
	private String team;
	
	private String createdBy;
	
	private LocalDateTime createdOn;
	
	private LocalDateTime updatedOn;

	private String updatedBy;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeRole() {
		return employeeRole;
	}

	public void setEmployeeRole(String employeeRole) {
		this.employeeRole = employeeRole;
	}

	public String getProjectUnit() {
		return projectUnit;
	}

	public void setProjectUnit(String projectUnit) {
		this.projectUnit = projectUnit;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	
	
	public String getLineManager() {
		return lineManager;
	}

	public void setLineManager(String lineManager) {
		this.lineManager = lineManager;
	}
	

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAllocatedCity() {
		return allocatedCity;
	}

	public void setAllocatedCity(String allocatedCity) {
		this.allocatedCity = allocatedCity;
	}

	public String getCurrentCountry() {
		return currentCountry;
	}

	public void setCurrentCountry(String currentCountry) {
		this.currentCountry = currentCountry;
	}

	public String getCurrentCity() {
		return currentCity;
	}

	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Employee(Integer employeeId, String employeeName, String employeeRole, String projectUnit,
			String projectCode, String location, String allocatedCity, String currentCountry, String currentCity,
			LocalDate birthDate, String emailId, String team, String createdBy, LocalDateTime createdOn,
			LocalDateTime updatedOn, String updatedBy , String lineManager) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeRole = employeeRole;
		this.projectUnit = projectUnit;
		this.projectCode = projectCode;
		this.location = location;
		this.allocatedCity = allocatedCity;
		this.lineManager = lineManager;
		this.currentCountry = currentCountry;
		this.currentCity = currentCity;
		this.birthDate = birthDate;
		this.emailId = emailId;
		this.team = team;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeRole="
				+ employeeRole + ", projectUnit=" + projectUnit + ", projectCode=" + projectCode + ", location="
				+ location + ", allocatedCity=" + allocatedCity + ", currentCountry=" + currentCountry
				+ ", currentCity=" + currentCity + ", birthDate=" + birthDate + ", emailId=" + emailId + ", team="
				+ team + ",  createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", updatedOn=" + updatedOn + ", updatedBy=" + updatedBy + " lineManager = " + lineManager +"]";
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


}