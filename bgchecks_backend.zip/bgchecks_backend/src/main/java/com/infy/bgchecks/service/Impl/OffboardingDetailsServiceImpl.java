package com.infy.bgchecks.service.Impl;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;import com.infy.bgchecks.dto.OffboardingDetailsDto;
import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.repository.OffboardingDetailsRepository;
import com.infy.bgchecks.service.OffboardingDetailsService;

@Service
public class OffboardingDetailsServiceImpl implements OffboardingDetailsService{
	
	@Autowired
	OffboardingDetailsRepository offboardingDetailsRepository;
	
	@Autowired
	ModelMapper modelMapper;

	@Override
	public OffboardingDetails addOffboardingDetails(String role,OffboardingDetailsDto offboardingDetailsDto) {
		
		OffboardingDetails offboardingDetails = dtoToBgchecks(offboardingDetailsDto);
        offboardingDetails.setCreatedByUser(role);
        offboardingDetails.setUpdatedByUser(role);
        
        Optional<OffboardingDetails> optional = this.offboardingDetailsRepository.findByEmployeeId(offboardingDetailsDto.getEmployeeId());	         	
		
        if(optional.isPresent())
        {
        	return null;
        }else
        {
        	return this.offboardingDetailsRepository.save(offboardingDetails);
        }
	}
	
	@Override
	public Optional<OffboardingDetails> getOffboardingDetailsById(Integer employeeId) {
		Optional<OffboardingDetails> offboardingDetails = offboardingDetailsRepository.findByEmployeeId(employeeId);
		return offboardingDetails;
		
	}

	@Override
	public List<OffboardingDetails> searchOffboardingDetails(OffboardingDetails offboardingDetails) {
		List<OffboardingDetails> offboardingDetailsList = new ArrayList<>();
		if(offboardingDetails.getEmployeeId()!=null) {
			Optional<OffboardingDetails> offboardingDetailsOptional = this.offboardingDetailsRepository.findByEmployeeId(offboardingDetails.getEmployeeId());
			offboardingDetailsList.add(offboardingDetailsOptional.get());
		}
		else if(offboardingDetails.getName()!=null) {
			offboardingDetailsList = this.offboardingDetailsRepository.findByName(offboardingDetails.getName());
		}
		else if(offboardingDetails.getInfyMailId()!=null) {
			offboardingDetailsList = this.offboardingDetailsRepository.findByInfyMailId(offboardingDetails.getInfyMailId());
		}
		else if(offboardingDetails.getProjectUnit()!=null) {
			offboardingDetailsList = this.offboardingDetailsRepository.findByProjectUnit(offboardingDetails.getProjectUnit());
		}
		else if(offboardingDetails.getOverallStatus()!=null) {
			offboardingDetailsList = this.offboardingDetailsRepository.findByOverallStatus(offboardingDetails.getOverallStatus());
		}else {
			offboardingDetailsList = this.offboardingDetailsRepository.findAll();
		}
		return offboardingDetailsList;
	}
	
	@Override
	public OffboardingDetails updateOffboardingDetails(String role, OffboardingDetailsDto offboardingDetailsDto) throws Exception {

		OffboardingDetails offboardingDetails = this.offboardingDetailsRepository.findByEmployeeId(offboardingDetailsDto.getEmployeeId()).orElseThrow(()->new Exception("employee id not found"+offboardingDetailsDto.getEmployeeId()));
		
		if(offboardingDetailsDto.getInfyMailId()!=null && !(offboardingDetailsDto.getInfyMailId().trim().isEmpty())
				&& offboardingDetailsDto.getInfyMailId()!="") {
			offboardingDetails.setInfyMailId(offboardingDetailsDto.getInfyMailId());
		}
		if(!offboardingDetailsDto.getName().trim().isEmpty()) {
			offboardingDetails.setName(offboardingDetailsDto.getName());
		}	
		if(!offboardingDetailsDto.getProjectUnit().isEmpty()) {
			offboardingDetails.setProjectUnit(offboardingDetailsDto.getProjectUnit());
		}
		if(offboardingDetailsDto.getLyncFederationRevokeDate()!=null) {
			offboardingDetails.setLyncFederationRevokeDate(offboardingDetailsDto.getLyncFederationRevokeDate());
		}
		if(offboardingDetailsDto.getAllocationDelimitDate()!=null) {
			offboardingDetails.setAllocationDelimitDate(offboardingDetailsDto.getAllocationDelimitDate());
		}
		if(offboardingDetailsDto.getOdcAccessRevokeDate()!=null) {
			offboardingDetails.setOdcAccessRevokeDate(offboardingDetailsDto.getOdcAccessRevokeDate());
		}
		if(offboardingDetailsDto.getClientIdRevokeDate()!=null) {
			offboardingDetails.setClientIdRevokeDate(offboardingDetailsDto.getClientIdRevokeDate());
		}
		if(offboardingDetailsDto.getOverallStatus()!=null) {
			offboardingDetails.setOverallStatus(offboardingDetailsDto.getOverallStatus());
		}
		if(!offboardingDetailsDto.getLineManager().isEmpty()) {
			offboardingDetails.setLineManager(offboardingDetailsDto.getLineManager());
		}
		if(offboardingDetailsDto.getComments()!=null) {
			offboardingDetails.setComments(offboardingDetailsDto.getComments());
		}
		if(offboardingDetailsDto.getReason()!=null) {
			offboardingDetails.setReason(offboardingDetailsDto.getReason());
		}
		
		offboardingDetails.setUpdatedByUser(role);
		this.offboardingDetailsRepository.save(offboardingDetails);
		offboardingDetails.setCreatedByUser(offboardingDetails.getCreatedByUser());
		return offboardingDetails;
	}

	@Override
	public OffboardingDetails deleteOffboardingDetails(Integer employeeId) {
		
		Optional<OffboardingDetails> offboardingDetails = this.offboardingDetailsRepository.findByEmployeeId(employeeId);
		if(offboardingDetails.isPresent()) {
			this.offboardingDetailsRepository.deleteById(offboardingDetails.get().getId());
			return offboardingDetails.get();
		}
		return null;
	}

	public OffboardingDetails dtoToBgchecks(OffboardingDetailsDto offboardingDetailsDto)
	{
		OffboardingDetails offboardingDetails = this.modelMapper.map(offboardingDetailsDto, OffboardingDetails.class);
		return offboardingDetails;
		
	}
	
	public OffboardingDetailsDto BgchecksToDto(Optional<OffboardingDetails> offboardingDetails) 
	{
		OffboardingDetailsDto offboardingDetailsDto = this.modelMapper.map(offboardingDetails, OffboardingDetailsDto.class);
		return offboardingDetailsDto;
	}

	@Override
	public List<String> autocompleteFields1(String fields) {
		List<String> data = new ArrayList<>();
		if(fields.equals("id")) {
			data = this.offboardingDetailsRepository.findAll().stream().map((details)-> details.getEmployeeId()+"").collect(Collectors.toList());
		}
		else if(fields.equals("name")) {
			data = this.offboardingDetailsRepository.findAll().stream().map((details)-> details.getName()).collect(Collectors.toList());
			data = data.stream().distinct().collect(Collectors.toList());
		}
		else if(fields.equals("mailid")) {
			data = this.offboardingDetailsRepository.findAll().stream().map((details)-> details.getInfyMailId()).collect(Collectors.toList());
			data.remove(null);
		}
		else if(fields.equals("overall_status")) {
			data = this.offboardingDetailsRepository.findAll().stream().map((details)-> details.getOverallStatus()).collect(Collectors.toList());
			data = data.stream().distinct().collect(Collectors.toList());
			data.remove(null);
		}
		return data;
	}


}
