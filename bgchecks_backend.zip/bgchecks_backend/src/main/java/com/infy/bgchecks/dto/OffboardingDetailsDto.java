package com.infy.bgchecks.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;


public class OffboardingDetailsDto {

	private Integer id;
    private Integer employeeId;
	private String infyMailId;
	private String name;
	private String projectUnit;
	private LocalDate lyncFederationRevokeDate;
	private LocalDate allocationDelimitDate;
	private LocalDate odcAccessRevokeDate;
	private LocalDate clientIdRevokeDate;
	private String overallStatus;
	private String lineManager;
	private String reason;
	private String comments;
	private LocalDateTime createdDate;
	private String createdByUser;
	private LocalDateTime updateDate;
	private String updatedByUser;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getInfyMailId() {
		return infyMailId;
	}

	public void setInfyMailId(String infyMailId) {
		this.infyMailId = infyMailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectUnit() {
		return projectUnit;
	}

	public void setProjectUnit(String projectUnit) {
		this.projectUnit = projectUnit;
	}

	public LocalDate getLyncFederationRevokeDate() {
		return lyncFederationRevokeDate;
	}

	public void setLyncFederationRevokeDate(LocalDate lyncFederationRevokeDate) {
		this.lyncFederationRevokeDate = lyncFederationRevokeDate;
	}

	public LocalDate getAllocationDelimitDate() {
		return allocationDelimitDate;
	}

	public void setAllocationDelimitDate(LocalDate allocationDelimitDate) {
		this.allocationDelimitDate = allocationDelimitDate;
	}

	public LocalDate getOdcAccessRevokeDate() {
		return odcAccessRevokeDate;
	}

	public void setOdcAccessRevokeDate(LocalDate odcAccessRevokeDate) {
		this.odcAccessRevokeDate = odcAccessRevokeDate;
	}

	public LocalDate getClientIdRevokeDate() {
		return clientIdRevokeDate;
	}

	public void setClientIdRevokeDate(LocalDate clientIdRevokeDate) {
		this.clientIdRevokeDate = clientIdRevokeDate;
	}

	public String getOverallStatus() {
		return overallStatus;
	}

	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public String getLineManager() {
		return lineManager;
	}

	public void setLineManager(String lineManager) {
		this.lineManager = lineManager;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}

	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatedByUser() {
		return updatedByUser;
	}

	public void setUpdatedByUser(String updatedByUser) {
		this.updatedByUser = updatedByUser;
	}

	public OffboardingDetailsDto() {
		super();
	}

	public OffboardingDetailsDto(Integer id, Integer employeeId, String infyMailId, String name, String projectUnit,
			LocalDate lyncFederationRevokeDate, LocalDate allocationDelimitDate, LocalDate odcAccessRevokeDate,
			LocalDate clientIdRevokeDate, String overallStatus, String lineManager, String reason, String comments,
			LocalDateTime createdDate, String createdByUser, LocalDateTime updateDate, String updatedByUser) {
		super();
		this.id = id;
		this.employeeId = employeeId;
		this.infyMailId = infyMailId;
		this.name = name;
		this.projectUnit = projectUnit;
		this.lyncFederationRevokeDate = lyncFederationRevokeDate;
		this.allocationDelimitDate = allocationDelimitDate;
		this.odcAccessRevokeDate = odcAccessRevokeDate;
		this.clientIdRevokeDate = clientIdRevokeDate;
		this.overallStatus = overallStatus;
		this.lineManager = lineManager;
		this.reason = reason;
		this.comments = comments;
		this.createdDate = createdDate;
		this.createdByUser = createdByUser;
		this.updateDate = updateDate;
		this.updatedByUser = updatedByUser;
	}

	@Override
	public String toString() {
		return "OffboardingDetails [id=" + id + ", employeeId=" + employeeId + ", infyMailId=" + infyMailId + ", name="
				+ name + ", projectUnit=" + projectUnit + ", lyncFederationRevokeDate=" + lyncFederationRevokeDate
				+ ", allocationDelimitDate=" + allocationDelimitDate + ", odcAccessRevokeDate=" + odcAccessRevokeDate
				+ ", clientIdRevokeDate=" + clientIdRevokeDate + ", overallStatus=" + overallStatus + ", lineManager="
				+ lineManager + ", reason=" + reason + ", comments=" + comments + ", createdDate=" + createdDate
				+ ", createdByUser=" + createdByUser + ", updateDate=" + updateDate + ", updatedByUser=" + updatedByUser
				+ "]";
	}
	
	
	
}

