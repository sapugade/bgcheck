package com.infy.bgchecks.service.Impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.HistoryOnboardingDetails;
import com.infy.bgchecks.entity.OnboardingDetails;
import com.infy.bgchecks.repository.HistoryOnboardingDetailsRepository;
import com.infy.bgchecks.service.HistoryOnboardingDetailsService;

@Service
public class HistoryOnboardingDetailsServiceImpl implements HistoryOnboardingDetailsService {

	@Autowired
	HistoryOnboardingDetailsRepository historyOnboardingDetailsRepo;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public void addHistoryOnboardingDetails(String role, OnboardingDetails onboardingDetails) {
		
		HistoryOnboardingDetails historyOnboardingDetails = dtoToHistoryOnboardingDetails(onboardingDetails);
		historyOnboardingDetails.setCreatedByUser(role);
		historyOnboardingDetails.setUpdatedByUser(role);
		historyOnboardingDetails.setAction("A");
		
		this.historyOnboardingDetailsRepo.save(historyOnboardingDetails);
		
	}


	@Override
	public void updateHistoryOnboardinDetails(String role, OnboardingDetails onboardingDetails) throws Exception {
		HistoryOnboardingDetails historyOnboardingDetails = dtoToHistoryOnboardingDetails(onboardingDetails);
		historyOnboardingDetails.setCreatedByUser(role);
		historyOnboardingDetails.setUpdatedByUser(role);
		historyOnboardingDetails.setAction("U");
		
		this.historyOnboardingDetailsRepo.save(historyOnboardingDetails);
	}

	@Override
	public void deleteHistoryOnboardinDetails(String role, OnboardingDetails onboardingDetails) {
		HistoryOnboardingDetails historyOnboardingDetails = dtoToHistoryOnboardingDetails(onboardingDetails);
		historyOnboardingDetails.setCreatedByUser(role);
		historyOnboardingDetails.setUpdatedByUser(role);
		historyOnboardingDetails.setAction("D");
		
		this.historyOnboardingDetailsRepo.save(historyOnboardingDetails);
	}
	

	private HistoryOnboardingDetails dtoToHistoryOnboardingDetails(OnboardingDetails onboardingDetails) {
		HistoryOnboardingDetails historyOnboardingDetails = this.modelMapper.map(onboardingDetails, HistoryOnboardingDetails.class);
		return historyOnboardingDetails;
	}
	

}
