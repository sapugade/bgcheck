package com.infy.bgchecks.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.Employee;

@CrossOrigin("*")
@RestController
@RequestMapping("/bgcheck")
public class RestTemplateController {
	
	@GetMapping("/getemployeedetailsbyid/{employeeId}/{token}")
	public ResponseEntity<OnboardingDetailsDto> getEmployeeDetailsById(@PathVariable("employeeId") Integer employeeId,
			@PathVariable("token") String token) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		Employee employee = restTemplate
				.exchange("http://localhost:8088/employeeportal/getemployeedetailbyid/" + employeeId, HttpMethod.POST,
						entity, Employee.class)
				.getBody();

		OnboardingDetailsDto onboardingDetailsDto = employeeToDto(employee);

		return new ResponseEntity<OnboardingDetailsDto>(onboardingDetailsDto, HttpStatus.OK);
	}
	
	@GetMapping("/getallemployeeid/{token}")
	public ResponseEntity<List<String>> getAllEmployeeId(@PathVariable("token") String token) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer " + token);
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		List<Map<String,String>> employeeIdList = restTemplate
				.exchange("http://localhost:8088/employeeportal/getemployee/id" , HttpMethod.GET,
						entity, List.class)
				.getBody();
		
		
		List<String> id = employeeIdList.stream().map((data) -> data.get("name")).collect(Collectors.toList());
			
		return new ResponseEntity<List<String>>(id, HttpStatus.OK);
	}

	private OnboardingDetailsDto employeeToDto(Employee employee) {
		OnboardingDetailsDto onboardingDetailsDto = new OnboardingDetailsDto();

		onboardingDetailsDto.setEmployeeId(employee.getEmployeeId());
		onboardingDetailsDto.setName(employee.getEmployeeName());
		onboardingDetailsDto.setInfyMailId(employee.getEmailId());
		onboardingDetailsDto.setProjectUnit(employee.getProjectUnit());
		onboardingDetailsDto.setLineManager(employee.getLineManager());

		return onboardingDetailsDto;
	}

}
