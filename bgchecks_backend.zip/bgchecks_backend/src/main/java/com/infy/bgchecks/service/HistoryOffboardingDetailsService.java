package com.infy.bgchecks.service;

import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.entity.OnboardingDetails;

public interface HistoryOffboardingDetailsService {

	void addHistoryOffboardingDetails(String role, OffboardingDetails offboardingDetails);

	void updateHistoryOffboardinDetails(String role, OffboardingDetails offboardingDetails) throws Exception;

	void deleteHistoryOffboardinDetails(String role, OffboardingDetails offboardingDetails);
	


}
