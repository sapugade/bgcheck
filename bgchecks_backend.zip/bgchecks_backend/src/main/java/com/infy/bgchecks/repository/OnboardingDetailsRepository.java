package com.infy.bgchecks.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.bgchecks.entity.OnboardingDetails;

public interface OnboardingDetailsRepository extends JpaRepository<OnboardingDetails, Integer> {
	
	Optional<OnboardingDetails> findByEmployeeId(Integer employeeId);

	List<OnboardingDetails> findByName(String name);

	List<OnboardingDetails> findByInfyMailId(String infyMailId);

	List<OnboardingDetails> findByProjectUnit(String projectUnit);

	List<OnboardingDetails> findByOverallStatus(String overallStatus);

}
