package com.infy.bgchecks;

import org.hibernate.tool.schema.spi.CommandAcceptanceException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.infy.bgchecks.dto.OffboardingDetailsDto;
import com.infy.bgchecks.service.OffboardingDetailsService;
import com.infy.bgchecks.service.Impl.OffboardingDetailsServiceImpl;

@SpringBootApplication
public class BgchecksBackendApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(BgchecksBackendApplication.class, args);
	}
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

}
