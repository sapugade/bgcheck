package com.infy.bgchecks.controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.bgchecks.dto.OffboardingDetailsDto;
import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.service.OffboardingDetailsService;


@CrossOrigin("*")
@RestController
@RequestMapping("/bgcheck/offboarding")
public class OffboardingDetailsController {

	@Autowired
	OffboardingDetailsService offboardingDetailsService;

	@Autowired
	HistoryOffboardingDetailsController historyOffboardingDetailsController;

	@PostMapping("/addoffboardingdetails")
	public ResponseEntity<OffboardingDetails> addOffboardingDetails(
			@RequestBody OffboardingDetailsDto offboardingDetailsDto) {
System.out.println(offboardingDetailsDto);
		String role = "admin";
		OffboardingDetails offboardingDetails = this.offboardingDetailsService.addOffboardingDetails(role,
				offboardingDetailsDto);
System.out.println(offboardingDetails);
		if (offboardingDetails !=null) {
			this.historyOffboardingDetailsController.addHistoryOffboardingDetails(role, offboardingDetails);
			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.NOT_MODIFIED);
		}
	}

	@PostMapping(value = {
			"/searchoffboardingdetails" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<OffboardingDetails>> serchOffboardingDetails(
			@RequestBody OffboardingDetails offboardingDetails) {

		List<OffboardingDetails> bgchecks1 = offboardingDetailsService.searchOffboardingDetails(offboardingDetails);
		if (bgchecks1.size() > 0) {
			return new ResponseEntity<List<OffboardingDetails>>(bgchecks1, HttpStatus.OK);
		} else {
			return new ResponseEntity<List<OffboardingDetails>>(bgchecks1, HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping("/getoffboardingdetailsbyid/{employeeId}")
	public ResponseEntity<Optional<OffboardingDetails>> getOffboardingDetailsById(@PathVariable Integer employeeId) {
		Optional<OffboardingDetails> optional = offboardingDetailsService.getOffboardingDetailsById(employeeId);
		return new ResponseEntity<Optional<OffboardingDetails>>(optional, HttpStatus.OK);
	}

	@PutMapping("/updateoffboardingdetails")
	public ResponseEntity<OffboardingDetails> updateOffboardingDetails(
			@RequestBody OffboardingDetailsDto offboardingDetailsDto) throws Exception {
		String role = "admin";
		OffboardingDetails offboardingDetails = this.offboardingDetailsService.updateOffboardingDetails(role,
				offboardingDetailsDto);

		if (!offboardingDetails.equals(null)) {
			this.historyOffboardingDetailsController.updateHistoryOffboardingDetails(role, offboardingDetails);
			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.OK);
		} else
			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.NOT_MODIFIED);

	}

	@DeleteMapping("/deleteoffboardingdetails/{employeeId}")
	public ResponseEntity<OffboardingDetails> deleteOffboardingDetails(@PathVariable Integer employeeId) {
		String role = "admin";
		OffboardingDetails offboardingDetails = offboardingDetailsService.getOffboardingDetailsById(employeeId).get();
		
		if (!offboardingDetails.equals(null)) {
			offboardingDetailsService.deleteOffboardingDetails(employeeId);
			this.historyOffboardingDetailsController.deleteHistoryOffboardingDetails(role, offboardingDetails);

			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.OK);
		} else {
			return new ResponseEntity<OffboardingDetails>(offboardingDetails, HttpStatus.BAD_GATEWAY);
		}
	}
	
	@GetMapping("/autocompletefields/{field}")
	public ResponseEntity<List<String>> autocompleteFields1(@PathVariable String field){
		List<String> data = this.offboardingDetailsService.autocompleteFields1(field);
		System.out.println(data);
		return new ResponseEntity<List<String>>(data, HttpStatus.OK);
	}


}

