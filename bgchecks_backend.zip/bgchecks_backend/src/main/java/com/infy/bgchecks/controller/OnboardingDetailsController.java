package com.infy.bgchecks.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.OnboardingDetails;
import com.infy.bgchecks.entity.Employee;
import com.infy.bgchecks.service.OnboardingDetailsService;

@CrossOrigin("*")
@RestController
@RequestMapping("/bgcheck")
public class OnboardingDetailsController {

	@Autowired
	OnboardingDetailsService onboardingDetailsService;

	@Autowired
	HistoryOnboardingDetailsController historyOnboardingDetailsController;

	@PostMapping("/addonboardingdetails")
	public ResponseEntity<OnboardingDetails> addOnboardingDetails(
			@RequestBody OnboardingDetailsDto onboardingDetailsDto) {

		String role = "admin";
		OnboardingDetails onboardingDetails = this.onboardingDetailsService.addOnboardingDetails(role,
				onboardingDetailsDto);

		if (!onboardingDetails.equals(null)) {
			this.historyOnboardingDetailsController.addHistoryOnboardingDetails(role, onboardingDetails);
			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.NOT_MODIFIED);
		}
	}

	@PostMapping(value = {
			"/searchonboardingdetails" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<OnboardingDetails>> serchOnboardingDetails(
			@RequestBody OnboardingDetails onboardingDetails) {

		List<OnboardingDetails> bgchecks1 = onboardingDetailsService.searchOnboardingDetails(onboardingDetails);
		if (bgchecks1.size() > 0) {
			return new ResponseEntity<List<OnboardingDetails>>(bgchecks1, HttpStatus.OK);
		} else {
			return new ResponseEntity<List<OnboardingDetails>>(bgchecks1, HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping("/getonboardingdetailsbyid/{employeeId}")
	public ResponseEntity<Optional<OnboardingDetails>> getOnboardingDetailsById(@PathVariable Integer employeeId) {
		Optional<OnboardingDetails> optional = onboardingDetailsService.getOnboardingDetailsById(employeeId);
		return new ResponseEntity<Optional<OnboardingDetails>>(optional, HttpStatus.OK);
	}

	@PutMapping("/updateonboardingdetails")
	public ResponseEntity<OnboardingDetails> updateOnboardingDetails(
			@RequestBody OnboardingDetailsDto onboardingDetailsDto) throws Exception {
		String role = "admin";
		OnboardingDetails onboardingDetails = this.onboardingDetailsService.updateOnboardingDetails(role,
				onboardingDetailsDto);

		if (!onboardingDetails.equals(null)) {
			this.historyOnboardingDetailsController.updateHistoryOnboardingDetails(role, onboardingDetails);
			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.OK);
		} else
			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.NOT_MODIFIED);

	}

	@DeleteMapping("/deleteonboardingdetails/{employeeId}")
	public ResponseEntity<OnboardingDetails> deleteOnboardingDetails(@PathVariable Integer employeeId) {
		String role = "admin";
		OnboardingDetails onboardingDetails = onboardingDetailsService.getOnboardingDetailsById(employeeId).get();
		
		if (!onboardingDetails.equals(null)) {
			onboardingDetailsService.deleteOnboardingDetails(employeeId);
			this.historyOnboardingDetailsController.deleteHistoryOnboardingDetails(role, onboardingDetails);

			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.OK);
		} else {
			return new ResponseEntity<OnboardingDetails>(onboardingDetails, HttpStatus.BAD_GATEWAY);
		}
	}
	
	@GetMapping("/autocompleteFields/{field}")
	public ResponseEntity<List<String>> autocompleteFields(@PathVariable String field){
		List<String> data = this.onboardingDetailsService.autocompleteFields(field);
		return new ResponseEntity<List<String>>(data, HttpStatus.OK);
	}


}
