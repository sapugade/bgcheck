package com.infy.bgchecks.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.service.HistoryOffboardingDetailsService;

@RestController
public class HistoryOffboardingDetailsController {
	
	@Autowired
	HistoryOffboardingDetailsService historyOffboardingDetailsService;

	public void addHistoryOffboardingDetails(String role, OffboardingDetails offboardingDetails) {
		// TODO Auto-generated method stub
		this.historyOffboardingDetailsService.addHistoryOffboardingDetails(role,offboardingDetails);
	}

	public void updateHistoryOffboardingDetails(String role, OffboardingDetails offboardingDetails) throws Exception {
		this.historyOffboardingDetailsService.updateHistoryOffboardinDetails(role, offboardingDetails);
		
	}

	public void deleteHistoryOffboardingDetails(String role, OffboardingDetails offboardingDetails) {
		this.historyOffboardingDetailsService.deleteHistoryOffboardinDetails(role, offboardingDetails);
	}
	
	

}

