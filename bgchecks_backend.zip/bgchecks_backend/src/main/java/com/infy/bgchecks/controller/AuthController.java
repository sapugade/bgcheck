package com.infy.bgchecks.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.bgchecks.dto.JwtAuthRequest;
import com.infy.bgchecks.dto.JwtAuthResponse;

@RestController
@CrossOrigin("http://localhost:4200/")
@RequestMapping("/bgcheck/authenticate")
public class AuthController {
	
	@GetMapping("/login")
	public ResponseEntity<JwtAuthResponse> getToken() {
		JwtAuthRequest request = new JwtAuthRequest("Shubham","shubham");	
		RestTemplate restTemplate = new RestTemplate();		
		JwtAuthResponse response = restTemplate.postForObject("http://localhost:8088/employeeportal/authenticate/login",request, JwtAuthResponse.class);
		System.out.println(response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
	
	
}
