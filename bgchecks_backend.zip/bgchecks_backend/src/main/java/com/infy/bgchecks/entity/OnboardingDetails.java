package com.infy.bgchecks.entity;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;



@Entity
@Table(name="onboarding_details")
public class OnboardingDetails {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="employee_id", nullable = false)
    private Integer employeeId;
	
	@Column(name="name", nullable = false, length = 64)
	private String name;
	
	@Column(name="infy_mail_id", nullable = true, length = 128)
	private String infyMailId;
	
	@Column(name="client_mail_id", nullable = true, length = 128)
	private String clientMailId;
	
	@Column(name="project_unit", nullable = false, length = 15)
	private String projectUnit;
	
	@Column(name="ahd_number", nullable = true, length = 15)
	private String ahdNumber;
	
	@Column(name="ahd_request_date",nullable = true)
	private LocalDate ahdRequestDate;
	
	@Column(name="initiation_date",nullable = true)
	private LocalDate initiationDate;
	
	@Column(name="initiation_vendor", nullable = true, length = 64)
	private String initiationVendor;
	
	@Column(name="case_ref_no_from_vendor", nullable = true, length = 15)
	private String caseRefNoFromVendor;
	
	@Column(name="bgc_location", nullable = true, length = 64)
	private String bgcLocation;
	
	@Column(name="legal_documents_signed", nullable = true, length = 1)
	private String legalDocumentsSigned;
	
	@Column(name="full_bgc_eta",nullable = true)
	private LocalDate fullBgcEta;
	
	@Column(name="bgc_minimum_comp_date",nullable = true)
	private LocalDate bgcMinimumCompletionDate;
	
	@Column(name="odc_access_date",nullable = true)
	private LocalDate odcAccessDate;
	
	@Column(name="re_grant_odc_access_date",nullable = true)
	private LocalDate reGrantOdcAccessDate;
	
	@Column(name="full_bg_comp_date",nullable = true)
	private LocalDate fullBgCompDate;
	
	@Column(name="age", nullable = true)
	private Integer age;
	
	@Column(name="overall_status", nullable = true, length = 64)
	private String overallStatus;
	
	@Column(name="line_manager", nullable = false, length = 64)
	private String lineManager;
	
	@Column(name="comments", nullable = true, length = 250)
	private String comments;
	
	@Column(name = "cre_date",nullable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;
	
	@Column(name = "cre_user",nullable = false, length = 64)
	private String createdByUser;
	
	@Column(name = "upd_date",nullable = false)
	@UpdateTimestamp
	private LocalDateTime updateDate;
	
	@Column(name = "upd_user",nullable = false, length = 64)
	private String updatedByUser;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInfyMailId() {
		return infyMailId;
	}

	public void setInfyMailId(String infyMailId) {
		this.infyMailId = infyMailId;
	}

	public String getClientMailId() {
		return clientMailId;
	}

	public void setClientMailId(String clientMailId) {
		this.clientMailId = clientMailId;
	}

	public String getProjectUnit() {
		return projectUnit;
	}

	public void setProjectUnit(String projectUnit) {
		this.projectUnit = projectUnit;
	}

	public String getAhdNumber() {
		return ahdNumber;
	}

	public void setAhdNumber(String ahdNumber) {
		this.ahdNumber = ahdNumber;
	}

	public LocalDate getAhdRequestDate() {
		return ahdRequestDate;
	}

	public void setAhdRequestDate(LocalDate ahdRequestDate) {
		this.ahdRequestDate = ahdRequestDate;
	}

	public LocalDate getInitiationDate() {
		return initiationDate;
	}

	public void setInitiationDate(LocalDate initiationDate) {
		this.initiationDate = initiationDate;
	}

	public String getInitiationVendor() {
		return initiationVendor;
	}

	public void setInitiationVendor(String initiationVendor) {
		this.initiationVendor = initiationVendor;
	}

	public String getCaseRefNoFromVendor() {
		return caseRefNoFromVendor;
	}

	public void setCaseRefNoFromVendor(String caseRefNoFromVendor) {
		this.caseRefNoFromVendor = caseRefNoFromVendor;
	}

	public String getBgcLocation() {
		return bgcLocation;
	}

	public void setBgcLocation(String bgcLocation) {
		this.bgcLocation = bgcLocation;
	}

	public String getLegalDocumentsSigned() {
		return legalDocumentsSigned;
	}

	public void setLegalDocumentsSigned(String legalDocumentsSigned) {
		this.legalDocumentsSigned = legalDocumentsSigned;
	}

	public LocalDate getFullBgcEta() {
		return fullBgcEta;
	}

	public void setFullBgcEta(LocalDate fullBgcEta) {
		this.fullBgcEta = fullBgcEta;
	}

	public LocalDate getBgcMinimumCompletionDate() {
		return bgcMinimumCompletionDate;
	}

	public void setBgcMinimumCompletionDate(LocalDate bgcMinimumCompletionDate) {
		this.bgcMinimumCompletionDate = bgcMinimumCompletionDate;
	}

	public LocalDate getOdcAccessDate() {
		return odcAccessDate;
	}

	public void setOdcAccessDate(LocalDate odcAccessDate) {
		this.odcAccessDate = odcAccessDate;
	}

	public LocalDate getReGrantOdcAccessDate() {
		return reGrantOdcAccessDate;
	}

	public void setReGrantOdcAccessDate(LocalDate reGrantOdcAccessDate) {
		this.reGrantOdcAccessDate = reGrantOdcAccessDate;
	}

	public LocalDate getFullBgCompDate() {
		return fullBgCompDate;
	}

	public void setFullBgCompDate(LocalDate fullBgCompDate) {
		this.fullBgCompDate = fullBgCompDate;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getOverallStatus() {
		return overallStatus;
	}

	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public String getLineManager() {
		return lineManager;
	}

	public void setLineManager(String lineManager) {
		this.lineManager = lineManager;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(String createdByUser) {
		this.createdByUser = createdByUser;
	}

	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatedByUser() {
		return updatedByUser;
	}

	public void setUpdatedByUser(String updatedByUser) {
		this.updatedByUser = updatedByUser;
	}

	public OnboardingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OnboardingDetails(Integer id, Integer employeeId, String name, String infyMailId, String clientMailId,
			String projectUnit, String ahdNumber, LocalDate ahdRequestDate, LocalDate initiationDate,
			String initiationVendor, String caseRefNoFromVendor, String bgcLocation, String legalDocumentsSigned,
			LocalDate fullBgcEta, LocalDate bgcMinimumCompletionDate, LocalDate odcAccessDate,
			LocalDate reGrantOdcAccessDate, LocalDate fullBgCompDate, Integer age, String overallStatus,
			String lineManager, String comments, LocalDateTime createdDate, String createdByUser,
			LocalDateTime updateDate, String updatedByUser) {
		super();
		this.id = id;
		this.employeeId = employeeId;
		this.name = name;
		this.infyMailId = infyMailId;
		this.clientMailId = clientMailId;
		this.projectUnit = projectUnit;
		this.ahdNumber = ahdNumber;
		this.ahdRequestDate = ahdRequestDate;
		this.initiationDate = initiationDate;
		this.initiationVendor = initiationVendor;
		this.caseRefNoFromVendor = caseRefNoFromVendor;
		this.bgcLocation = bgcLocation;
		this.legalDocumentsSigned = legalDocumentsSigned;
		this.fullBgcEta = fullBgcEta;
		this.bgcMinimumCompletionDate = bgcMinimumCompletionDate;
		this.odcAccessDate = odcAccessDate;
		this.reGrantOdcAccessDate = reGrantOdcAccessDate;
		this.fullBgCompDate = fullBgCompDate;
		this.age = age;
		this.overallStatus = overallStatus;
		this.lineManager = lineManager;
		this.comments = comments;
		this.createdDate = createdDate;
		this.createdByUser = createdByUser;
		this.updateDate = updateDate;
		this.updatedByUser = updatedByUser;
	}

	@Override
	public String toString() {
		return "Bgchecks [id=" + id + ", employeeId=" + employeeId + ", name=" + name + ", infyMailId=" + infyMailId
				+ ", clientMailId=" + clientMailId + ", projectUnit=" + projectUnit + ", ahdNumber=" + ahdNumber
				+ ", ahdRequestDate=" + ahdRequestDate + ", initiationDate=" + initiationDate + ", initiationVendor="
				+ initiationVendor + ", caseRefNoFromVendor=" + caseRefNoFromVendor + ", bgcLocation=" + bgcLocation
				+ ", legalDocumentsSigned=" + legalDocumentsSigned + ", fullBgcEta=" + fullBgcEta
				+ ", bgcMinimumCompletionDate=" + bgcMinimumCompletionDate + ", odcAccessDate=" + odcAccessDate
				+ ", reGrantOdcAccessDate=" + reGrantOdcAccessDate + ", fullBgCompDate=" + fullBgCompDate + ", age="
				+ age + ", overallStatus=" + overallStatus + ", lineManager=" + lineManager + ", comments=" + comments
				+ ", createdDate=" + createdDate + ", createdByUser=" + createdByUser + ", updateDate=" + updateDate
				+ ", updatedByUser=" + updatedByUser + "]";
	}

	
}
