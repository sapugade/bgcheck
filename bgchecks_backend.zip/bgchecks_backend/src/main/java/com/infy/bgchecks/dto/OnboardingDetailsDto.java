package com.infy.bgchecks.dto;

import java.time.LocalDate;

public class OnboardingDetailsDto {
	
	private Integer employeeId;
	private String name;
	private String infyMailId;
	private String clientMailId;
	private String projectUnit;
	private String ahdNumber;
	private LocalDate ahdRequestDate;
	private LocalDate initiationDate;
	private String initiationVendor;
	private String caseRefNoFromVendor;
	private String bgcLocation;
	private String legalDocumentsSigned;
	private LocalDate fullBgcEta;
	private LocalDate bgcMinimumCompletionDate;
	private LocalDate odcAccessDate;
	private LocalDate reGrantOdcAccessDate;
	private LocalDate fullBgCompDate;
	private Integer age;
	private String overallStatus;
	private String lineManager;
	private String comments;
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInfyMailId() {
		return infyMailId;
	}
	public void setInfyMailId(String infyMailId) {
		this.infyMailId = infyMailId;
	}
	public String getClientMailId() {
		return clientMailId;
	}
	public void setClientMailId(String clientMailId) {
		this.clientMailId = clientMailId;
	}
	public String getProjectUnit() {
		return projectUnit;
	}
	public void setProjectUnit(String projectUnit) {
		this.projectUnit = projectUnit;
	}
	public String getAhdNumber() {
		return ahdNumber;
	}
	public void setAhdNumber(String ahdNumber) {
		this.ahdNumber = ahdNumber;
	}
	public LocalDate getAhdRequestDate() {
		return ahdRequestDate;
	}
	public void setAhdRequestDate(LocalDate ahdRequestDate) {
		this.ahdRequestDate = ahdRequestDate;
	}
	public LocalDate getInitiationDate() {
		return initiationDate;
	}
	public void setInitiationDate(LocalDate initiationDate) {
		this.initiationDate = initiationDate;
	}
	public String getInitiationVendor() {
		return initiationVendor;
	}
	public void setInitiationVendor(String initiationVendor) {
		this.initiationVendor = initiationVendor;
	}
	public String getCaseRefNoFromVendor() {
		return caseRefNoFromVendor;
	}
	public void setCaseRefNoFromVendor(String caseRefNoFromVendor) {
		this.caseRefNoFromVendor = caseRefNoFromVendor;
	}
	public String getBgcLocation() {
		return bgcLocation;
	}
	public void setBgcLocation(String bgcLocation) {
		this.bgcLocation = bgcLocation;
	}
	public String getLegalDocumentsSigned() {
		return legalDocumentsSigned;
	}
	public void setLegalDocumentsSigned(String legalDocumentsSigned) {
		this.legalDocumentsSigned = legalDocumentsSigned;
	}
	public LocalDate getFullBgcEta() {
		return fullBgcEta;
	}
	public void setFullBgcEta(LocalDate fullBgcEta) {
		this.fullBgcEta = fullBgcEta;
	}
	public LocalDate getBgcMinimumCompletionDate() {
		return bgcMinimumCompletionDate;
	}
	public void setBgcMinimumCompletionDate(LocalDate bgcMinimumCompletionDate) {
		this.bgcMinimumCompletionDate = bgcMinimumCompletionDate;
	}
	public LocalDate getOdcAccessDate() {
		return odcAccessDate;
	}
	public void setOdcAccessDate(LocalDate odcAccessDate) {
		this.odcAccessDate = odcAccessDate;
	}
	public LocalDate getReGrantOdcAccessDate() {
		return reGrantOdcAccessDate;
	}
	public void setReGrantOdcAccessDate(LocalDate reGrantOdcAccessDate) {
		this.reGrantOdcAccessDate = reGrantOdcAccessDate;
	}
	public LocalDate getFullBgCompDate() {
		return fullBgCompDate;
	}
	public void setFullBgCompDate(LocalDate fullBgCompDate) {
		this.fullBgCompDate = fullBgCompDate;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getOverallStatus() {
		return overallStatus;
	}
	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}
	public String getLineManager() {
		return lineManager;
	}
	public void setLineManager(String lineManager) {
		this.lineManager = lineManager;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public OnboardingDetailsDto(Integer employeeId, String name, String infyMailId, String clientMailId, String projectUnit,
			String ahdNumber, LocalDate ahdRequestDate, LocalDate initiationDate, String initiationVendor,
			String caseRefNoFromVendor, String bgcLocation, String legalDocumentsSigned, LocalDate fullBgcEta,
			LocalDate bgcMinimumCompletionDate, LocalDate odcAccessDate, LocalDate reGrantOdcAccessDate, LocalDate fullBgCompDate,
			Integer age, String overallStatus, String lineManager, String comments) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.infyMailId = infyMailId;
		this.clientMailId = clientMailId;
		this.projectUnit = projectUnit;
		this.ahdNumber = ahdNumber;
		this.ahdRequestDate = ahdRequestDate;
		this.initiationDate = initiationDate;
		this.initiationVendor = initiationVendor;
		this.caseRefNoFromVendor = caseRefNoFromVendor;
		this.bgcLocation = bgcLocation;
		this.legalDocumentsSigned = legalDocumentsSigned;
		this.fullBgcEta = fullBgcEta;
		this.bgcMinimumCompletionDate = bgcMinimumCompletionDate;
		this.odcAccessDate = odcAccessDate;
		this.reGrantOdcAccessDate = reGrantOdcAccessDate;
		this.fullBgCompDate = fullBgCompDate;
		this.age = age;
		this.overallStatus = overallStatus;
		this.lineManager = lineManager;
		this.comments = comments;
	}
	public OnboardingDetailsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BgchecksDto [employeeId=" + employeeId + ", name=" + name + ", infyMailId=" + infyMailId
				+ ", clientMailId=" + clientMailId + ", projectUnit=" + projectUnit + ", ahdNumber=" + ahdNumber
				+ ", ahdRequestDate=" + ahdRequestDate + ", initiationDate=" + initiationDate + ", initiationVendor="
				+ initiationVendor + ", caseRefNoFromVendor=" + caseRefNoFromVendor + ", bgcLocation=" + bgcLocation
				+ ", legalDocumentsSigned=" + legalDocumentsSigned + ", fullBgcEta=" + fullBgcEta
				+ ", bgcMinimumCompletionDate=" + bgcMinimumCompletionDate + ", odcAccessDate=" + odcAccessDate
				+ ", reGrantOdcAccessDate=" + reGrantOdcAccessDate + ", fullBgCompDate=" + fullBgCompDate + ", age="
				+ age + ", overallStatus=" + overallStatus + ", lineManager=" + lineManager + ", comments=" + comments
				+ "]";
	}
	
	
}
