package com.infy.bgchecks.service;

import java.util.List;
import java.util.Optional;

import com.infy.bgchecks.dto.OffboardingDetailsDto;
import com.infy.bgchecks.entity.OffboardingDetails;
import com.infy.bgchecks.entity.OnboardingDetails;

public interface OffboardingDetailsService {

	OffboardingDetails addOffboardingDetails(String role, OffboardingDetailsDto offboardingDetailsDto);

	List<OffboardingDetails> searchOffboardingDetails(OffboardingDetails offboardingDetails);

	OffboardingDetails updateOffboardingDetails(String role, OffboardingDetailsDto offboardingDetailsDto)
			throws Exception;

	Optional<OffboardingDetails> getOffboardingDetailsById(Integer employeeId);

	OffboardingDetails deleteOffboardingDetails(Integer employeeId);

	List<String> autocompleteFields1(String fields);

}
