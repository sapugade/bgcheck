package com.infy.bgchecks.service;

import java.util.List;
import java.util.Optional;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.OnboardingDetails;


public interface OnboardingDetailsService {
	
	public OnboardingDetails addOnboardingDetails(String role,OnboardingDetailsDto onboardingDetailsDto);
	
	public OnboardingDetails updateOnboardingDetails(String role,OnboardingDetailsDto onboardingDetailsDto) throws Exception;
	
	public OnboardingDetails deleteOnboardingDetails(Integer employeeId);

	public Optional<OnboardingDetails> getOnboardingDetailsById(Integer employeeId);

	public List<OnboardingDetails> searchOnboardingDetails(OnboardingDetails onboardingDetails);

	public List<String> autocompleteFields(String fields);

}
