package com.infy.bgchecks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.infy.bgchecks.dto.OnboardingDetailsDto;
import com.infy.bgchecks.entity.OnboardingDetails;
import com.infy.bgchecks.service.HistoryOnboardingDetailsService;

@RestController
public class HistoryOnboardingDetailsController {
	
	@Autowired
	HistoryOnboardingDetailsService historyOnboardingDetailsService;

	public void addHistoryOnboardingDetails(String role, OnboardingDetails onboardingDetails) {
		// TODO Auto-generated method stub
		this.historyOnboardingDetailsService.addHistoryOnboardingDetails(role,onboardingDetails);
	}

	public void updateHistoryOnboardingDetails(String role, OnboardingDetails onboardingDetails) throws Exception {
		this.historyOnboardingDetailsService.updateHistoryOnboardinDetails(role, onboardingDetails);
		
	}

	public void deleteHistoryOnboardingDetails(String role, OnboardingDetails onboardingDetails) {
		this.historyOnboardingDetailsService.deleteHistoryOnboardinDetails(role, onboardingDetails);
	}
	
	

}
