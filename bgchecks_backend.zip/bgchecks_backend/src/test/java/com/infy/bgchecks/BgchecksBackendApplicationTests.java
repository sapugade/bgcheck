package com.infy.bgchecks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BgchecksBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
