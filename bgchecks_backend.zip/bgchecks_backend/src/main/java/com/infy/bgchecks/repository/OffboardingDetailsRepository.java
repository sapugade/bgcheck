package com.infy.bgchecks.repository;

import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.bgchecks.entity.OffboardingDetails;

public interface OffboardingDetailsRepository extends JpaRepository<OffboardingDetails, Integer> {
	
	Optional<OffboardingDetails> findByEmployeeId(Integer employeeId);

	List<OffboardingDetails> findByName(String name);

	List<OffboardingDetails> findByInfyMailId(String infyMailId);

	List<OffboardingDetails> findByProjectUnit(String projectUnit);

	List<OffboardingDetails> findByOverallStatus(String overallStatus);

}
