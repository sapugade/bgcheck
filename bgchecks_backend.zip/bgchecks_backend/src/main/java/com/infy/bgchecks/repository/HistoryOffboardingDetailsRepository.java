package com.infy.bgchecks.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.bgchecks.entity.HistoryOffboardingDetails;

@Repository
public interface HistoryOffboardingDetailsRepository extends JpaRepository<HistoryOffboardingDetails, Integer> {

}
